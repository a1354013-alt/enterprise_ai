# 🚀 快速開始指南

## 5 分鐘快速上手企業 AI 助理

### 第一步：啟動後端 (終端 1)

```bash
cd enterprise-ai-assistant/backend
pip install -r requirements.txt
python main.py
```

✅ 看到 `Uvicorn running on http://0.0.0.0:8000` 即成功

### 第二步：啟動前端 (終端 2)

```bash
cd enterprise-ai-assistant/frontend
pnpm install
pnpm dev
```

✅ 看到 `Local: http://localhost:3000` 即成功

### 第三步：打開瀏覽器

訪問 http://localhost:3000

### 第四步：測試功能

#### 1️⃣ 上傳文件
- 點擊「選擇文件」
- 選擇 `backend/sample_docs/leave_policy.txt`
- 點擊「上傳文件」
- 看到「文件上傳成功」提示

#### 2️⃣ 測試問答
- 在「智能問答」區輸入：`請假規定是什麼？`
- 點擊「提交問題」
- 看到回答和引用來源

#### 3️⃣ 生成表單
- 在「表單生成」區選擇「請假通知」
- 填寫表單欄位：
  - 請假類型：年假
  - 請假日期：2026-02-10
  - 請假天數：3
  - 原因：個人休息
- 點擊「生成內容」
- 點擊「複製內容」

## 🎯 核心功能演示

### 文件管理
```
✅ 上傳 PDF/TXT/MD 文件
✅ 自動索引到向量庫
✅ 支援角色權限設定
✅ 一鍵刪除
```

### 智能問答
```
✅ 基於文件的 RAG 問答
✅ 顯示引用來源
✅ 支援多個問題
✅ 角色權限過濾
```

### 表單生成
```
✅ 請假通知
✅ 加班申請說明
✅ 變更申請摘要
✅ 會議紀錄
```

## 🔑 環境變數 (可選)

編輯 `backend/.env` 以使用 OpenAI API：

```env
OPENAI_API_KEY=sk-your-api-key-here
```

不設定也能用 Demo Mode！

## 📝 範例文件位置

```
backend/sample_docs/
├── leave_policy.txt      # 請假規定
├── overtime_policy.txt   # 加班規定
└── meeting_template.txt  # 會議模板
```

## 🐛 常見問題

**Q: 後端連接失敗？**
A: 確保後端運行在 http://localhost:8000，檢查防火牆

**Q: 文件上傳失敗？**
A: 確保文件格式為 PDF/TXT/MD，檢查 `backend/uploads/` 目錄

**Q: 問答無結果？**
A: 確認已上傳文件，檢查當前角色權限

**Q: 需要 OpenAI API Key？**
A: 不需要！沒有 key 也能用 Demo Mode

## 📚 API 文檔

後端 Swagger UI: http://localhost:8000/docs

## 🎨 前端技術

- React 19 + Tailwind 4
- shadcn/ui 組件
- Axios HTTP 客戶端
- Sonner Toast 通知

## 🔧 後端技術

- FastAPI
- ChromaDB 向量庫
- LangChain 文本分割
- PyPDF 文件解析

## 📞 需要幫助？

1. 查閱 README.md 詳細文檔
2. 檢查終端輸出錯誤信息
3. 查看瀏覽器開發者工具 (F12)

---

**祝您使用愉快！** 🎉

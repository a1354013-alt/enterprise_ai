# 企業內部 AI 助理 MVP

一個完整的企業內部 AI 助理雛形，提供 **SOP/規章/表單** 的查詢、引用式回答、以及表單內容生成功能。

## 🎯 核心功能

### 1. 文件管理
- ✅ 上傳文件 (PDF / TXT / MD)
- ✅ 列出已上傳文件
- ✅ 刪除文件
- ✅ 角色權限控制 (employee / manager / hr)

### 2. RAG 索引系統
- ✅ 自動文本分割 (500 tokens, 100 overlap)
- ✅ ChromaDB 向量庫存儲
- ✅ 元數據保存 (doc_id, filename, page, allowed_roles)

### 3. 智能問答
- ✅ 基於檢索的回答 (RAG)
- ✅ 顯示引用來源 (doc_name, chunk_text, page)
- ✅ 角色權限過濾
- ✅ 支援 OpenAI API 或 Demo Mode

### 4. 表單生成
- ✅ 請假通知
- ✅ 加班申請說明
- ✅ 變更申請摘要
- ✅ 會議紀錄
- ✅ 支援自訂輸入欄位

### 5. 權限管理
- ✅ 三層角色: employee / manager / hr
- ✅ 文件級別的角色權限
- ✅ 檢索時自動過濾

## 🛠️ 技術棧

| 層級 | 技術 |
|------|------|
| **前端** | React 19 + Tailwind 4 + shadcn/ui |
| **後端** | Python FastAPI |
| **向量庫** | ChromaDB (本機) |
| **LLM** | OpenAI API (可選) |
| **文件解析** | PyPDF + LangChain |

## 📦 專案結構

```
enterprise-ai-assistant/
├── backend/                      # FastAPI 後端
│   ├── main.py                  # 主應用程式
│   ├── models.py                # Pydantic 模型
│   ├── database.py              # ChromaDB 操作
│   ├── services.py              # 業務邏輯
│   ├── requirements.txt          # Python 依賴
│   ├── .env                     # 環境變數
│   ├── uploads/                 # 上傳文件目錄
│   ├── chroma_db/               # ChromaDB 本機存儲
│   └── sample_docs/             # 範例文件
│       ├── leave_policy.txt     # 請假規定
│       ├── overtime_policy.txt  # 加班規定
│       └── meeting_template.txt # 會議模板
│
└── frontend/                     # React 前端
    ├── client/
    │   ├── src/
    │   │   ├── pages/
    │   │   │   └── Home.tsx     # 主頁面 (文件/問答/表單)
    │   │   ├── App.tsx          # 路由配置
    │   │   └── index.css        # 全局樣式
    │   └── index.html
    ├── package.json
    └── vite.config.ts
```

## 🚀 快速開始

### 前置要求
- Python 3.8+
- Node.js 18+
- pnpm (或 npm/yarn)

### 1️⃣ 後端啟動

```bash
cd enterprise-ai-assistant/backend

# 安裝依賴
pip install -r requirements.txt

# 設定環境變數 (可選)
# 編輯 .env，設定 OPENAI_API_KEY (若有)

# 啟動伺服器
python main.py
```

後端將在 `http://localhost:8000` 運行

**API 文檔**: http://localhost:8000/docs (Swagger UI)

### 2️⃣ 前端啟動

```bash
cd enterprise-ai-assistant/frontend

# 安裝依賴
pnpm install

# 啟動開發伺服器
pnpm dev
```

前端將在 `http://localhost:3000` 運行

### 3️⃣ 測試流程

1. **打開前端**: http://localhost:3000
2. **選擇角色**: 在右上角選擇 `employee` / `manager` / `hr`
3. **上傳文件**: 
   - 點擊「選擇文件」，選擇 `backend/sample_docs/` 中的文件
   - 選擇允許查看的角色
   - 點擊「上傳文件」
4. **測試問答**:
   - 輸入問題，例如：「請假規定是什麼？」
   - 點擊「提交問題」
   - 查看回答和引用來源
5. **生成表單**:
   - 選擇模板，例如：「請假通知」
   - 填寫表單欄位
   - 點擊「生成內容」
   - 複製生成的內容

## 🔧 API 端點

### 文件管理

**上傳文件**
```bash
POST /api/docs/upload
Content-Type: multipart/form-data

Parameters:
- file: 文件 (PDF/TXT/MD)
- allowed_roles: 允許查看的角色 (預設: employee)

Response:
{
  "id": "uuid",
  "filename": "leave_policy.txt",
  "allowed_roles": ["employee"]
}
```

**列出文件**
```bash
GET /api/docs

Response:
[
  {
    "id": "uuid",
    "filename": "leave_policy.txt",
    "allowed_roles": ["employee"]
  }
]
```

**刪除文件**
```bash
DELETE /api/docs/{doc_id}

Response:
{ "status": "deleted" }
```

### 問答

**提交問題**
```bash
POST /api/qa

Request:
{
  "question": "請假規定是什麼？",
  "user_role": "employee"
}

Response:
{
  "answer": "根據企業規定，...",
  "sources": [
    {
      "doc_name": "leave_policy.txt",
      "chunk_text": "年假：新員工第一年 10 天...",
      "page_or_section": "0"
    }
  ]
}
```

### 表單生成

**生成內容**
```bash
POST /api/generate

Request:
{
  "template_type": "請假通知",
  "inputs": {
    "請假類型": "年假",
    "請假日期": "2026-02-10",
    "請假天數": "3",
    "原因": "個人休息"
  },
  "user_role": "employee"
}

Response:
{
  "content": "親愛的團隊，\n關於請假通知，細節如下：...\n此致，\nemployee 助理代筆"
}
```

## 🔑 環境變數

編輯 `backend/.env`:

```env
# OpenAI API Key (可選，沒有 key 也能用 Demo Mode)
# OPENAI_API_KEY=sk-your-api-key-here

# 後端伺服器設定
BACKEND_HOST=0.0.0.0
BACKEND_PORT=8000

# ChromaDB 設定
CHROMA_DB_PATH=./chroma_db
```

### 使用 OpenAI API

1. 從 https://platform.openai.com/api-keys 獲取 API Key
2. 在 `backend/.env` 中設定:
   ```env
   OPENAI_API_KEY=sk-your-actual-key
   ```
3. 重啟後端伺服器

### Demo Mode (無需 API Key)

如果未設定 `OPENAI_API_KEY` 或 Key 無效，系統會自動使用 Demo Mode：
- 問答會顯示模擬回答
- 表單生成會使用簡單模板
- 所有功能仍可正常使用

## 📝 範例文件

已提供三份範例文件，位於 `backend/sample_docs/`:

### 1. `leave_policy.txt` - 請假規定
包含：年假、病假、事假、喪假、婚假、產假、申請流程

### 2. `overtime_policy.txt` - 加班規定
包含：加班申請條件、補償方式、時間安排、申請流程、記錄方式

### 3. `meeting_template.txt` - 會議紀錄模板
包含：會議基本資訊、議題、待辦事項、下次會議

## 🎨 前端特性

- ✅ 三欄布局 (文件 / 問答 / 表單)
- ✅ 角色切換下拉選單
- ✅ 實時檔案上傳
- ✅ 引用卡片展示
- ✅ 內容複製功能
- ✅ 響應式設計
- ✅ 加載狀態指示
- ✅ Toast 通知

## 🔐 權限模型

### 角色定義

| 角色 | 描述 | 預設權限 |
|------|------|---------|
| `employee` | 員工 | 可查看員工級別文件 |
| `manager` | 主管 | 可查看員工 + 主管級別文件 |
| `hr` | 人資 | 可查看所有文件 |

### 權限過濾邏輯

1. 上傳文件時指定 `allowed_roles`
2. 問答時根據 `user_role` 過濾
3. 只返回當前角色有權限查看的文件

**範例**:
- 上傳文件時設定 `allowed_roles=["manager"]`
- 員工角色提問時，該文件不會被檢索
- 主管角色提問時，該文件會被檢索

## 🐛 故障排除

### 後端無法連接
```bash
# 檢查後端是否運行
curl http://localhost:8000/docs

# 檢查防火牆設定
# 確保 8000 端口未被佔用
```

### 文件上傳失敗
```bash
# 檢查 uploads 目錄是否存在
ls -la backend/uploads/

# 檢查文件格式 (必須是 PDF/TXT/MD)
file backend/sample_docs/leave_policy.txt
```

### 問答無結果
1. 確認已上傳文件
2. 檢查當前角色是否有權限查看文件
3. 嘗試用不同的問題措辭

### ChromaDB 錯誤
```bash
# 清除本機向量庫
rm -rf backend/chroma_db/

# 重新上傳文件以重建索引
```

## 📚 進階配置

### 修改文本分割參數

編輯 `backend/services.py`:
```python
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,      # 改為 1000 以增大分割塊
    chunk_overlap=100    # 改為 200 以增加重疊
)
```

### 修改檢索結果數量

編輯 `backend/database.py`:
```python
def query_vector_db(query_text: str, n_results: int = 3):  # 改為 5 或更多
```

### 添加新的表單模板

編輯 `backend/services.py`:
```python
templates = {
    "請假通知": "...",
    "新模板": "請幫我生成一份新模板：{inputs}",
}
```

編輯 `frontend/client/src/pages/Home.tsx`:
```tsx
<SelectItem value="新模板">新模板</SelectItem>
```

## 🚀 生產部署

### 後端部署 (使用 Gunicorn)
```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:8000 main:app
```

### 前端部署
```bash
pnpm build
# 將 dist/ 目錄部署到 CDN 或靜態伺服器
```

### Docker 部署 (可選)

**後端 Dockerfile**:
```dockerfile
FROM python:3.11
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "main.py"]
```

**前端 Dockerfile**:
```dockerfile
FROM node:18
WORKDIR /app
COPY package.json pnpm-lock.yaml .
RUN npm install -g pnpm && pnpm install
COPY . .
RUN pnpm build
CMD ["pnpm", "preview"]
```

## 📄 授權

MIT License

## 🤝 貢獻

歡迎提交 Issue 和 Pull Request！

## 📞 支援

如有問題，請查閱：
- API 文檔: http://localhost:8000/docs
- 前端日誌: 瀏覽器開發者工具 (F12)
- 後端日誌: 終端輸出

---

**版本**: 1.0.0 MVP  
**最後更新**: 2026-02-05

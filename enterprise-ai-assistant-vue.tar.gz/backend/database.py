import os
import chromadb
from chromadb.utils import embedding_functions
from typing import List

# 使用 ChromaDB 本機存儲
CHROMA_DATA_PATH = "./chroma_db"
COLLECTION_NAME = "enterprise_docs"

# 初始化 ChromaDB 客戶端
client = chromadb.PersistentClient(path=CHROMA_DATA_PATH)

# 使用預設的 Embedding 函數 (如果沒有 OpenAI API Key，ChromaDB 會使用預設模型)
# 若要用 OpenAI: embedding_functions.OpenAIEmbeddingFunction(api_key=os.getenv("OPENAI_API_KEY"))
def get_collection():
    return client.get_or_create_collection(
        name=COLLECTION_NAME,
        metadata={"hnsw:space": "cosine"}
    )

def add_to_vector_db(chunks: List[str], metadatas: List[dict], ids: List[str]):
    collection = get_collection()
    collection.add(
        documents=chunks,
        metadatas=metadatas,
        ids=ids
    )

def query_vector_db(query_text: str, n_results: int = 3, where_filter: dict = None):
    collection = get_collection()
    results = collection.query(
        query_texts=[query_text],
        n_results=n_results,
        where=where_filter
    )
    return results

def delete_from_vector_db(doc_id: str):
    collection = get_collection()
    collection.delete(where={"doc_id": doc_id})

import os
import shutil
from typing import List
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from models import QARequest, QAResponse, GenerateRequest, GenerateResponse, DocumentResponse
from services import process_file, perform_qa, generate_form
from database import delete_from_vector_db

app = FastAPI(title="Enterprise AI Assistant API")

# 允許跨域
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = "uploads"
if not os.path.exists(UPLOAD_DIR):
    os.makedirs(UPLOAD_DIR)

# 模擬資料庫存儲文件列表
docs_db = []

@app.post("/api/docs/upload")
async def upload_document(
    file: UploadFile = File(...),
    allowed_roles: str = Form("employee")
):
    file_path = os.path.join(UPLOAD_DIR, file.filename)
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    
    roles = allowed_roles.split(",")
    doc_id = process_file(file_path, file.filename, roles)
    
    if doc_id:
        doc_info = {"id": doc_id, "filename": file.filename, "allowed_roles": roles}
        docs_db.append(doc_info)
        return doc_info
    raise HTTPException(status_code=500, detail="文件處理失敗")

@app.get("/api/docs", response_model=List[DocumentResponse])
async def list_documents():
    return docs_db

@app.delete("/api/docs/{doc_id}")
async def delete_document(doc_id: str):
    global docs_db
    # 刪除向量庫中的資料
    delete_from_vector_db(doc_id)
    # 刪除清單中的資料
    docs_db = [d for d in docs_db if d["id"] != doc_id]
    return {"status": "deleted"}

@app.post("/api/qa", response_model=QAResponse)
async def qa_endpoint(request: QARequest):
    answer, sources = await perform_qa(request.question, request.user_role)
    return QAResponse(answer=answer, sources=sources)

@app.post("/api/generate", response_model=GenerateResponse)
async def generate_endpoint(request: GenerateRequest):
    content = await generate_form(request.template_type, request.inputs, request.user_role)
    return GenerateResponse(content=content)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

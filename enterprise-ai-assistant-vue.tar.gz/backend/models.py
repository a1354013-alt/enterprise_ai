from pydantic import BaseModel
from typing import List, Optional

class DocumentResponse(BaseModel):
    id: str
    filename: str
    allowed_roles: List[str]

class QARequest(BaseModel):
    question: str
    user_role: str

class Source(BaseModel):
    doc_name: str
    chunk_text: str
    page_or_section: str

class QAResponse(BaseModel):
    answer: str
    sources: List[Source]

class GenerateRequest(BaseModel):
    template_type: str
    inputs: dict
    user_role: str

class GenerateResponse(BaseModel):
    content: str

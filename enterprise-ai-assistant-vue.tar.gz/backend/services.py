import os
import uuid
from typing import List
from langchain_openai import ChatOpenAI
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader, TextLoader
from database import add_to_vector_db, query_vector_db, delete_from_vector_db
from models import Source

# 初始化 LLM
# 如果沒有 API Key，則使用 Mock 回應
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

def get_llm():
    if OPENAI_API_KEY and OPENAI_API_KEY.startswith("sk-"):
        return ChatOpenAI(model="gpt-4o-mini", api_key=OPENAI_API_KEY)
    return None

def process_file(file_path: str, filename: str, allowed_roles: List[str]):
    doc_id = str(uuid.uuid4())
    
    # 根據副檔名選擇 Loader
    ext = os.path.splitext(filename)[1].lower()
    if ext == ".pdf":
        loader = PyPDFLoader(file_path)
    elif ext == ".txt":
        loader = TextLoader(file_path)
    elif ext == ".md":
        loader = TextLoader(file_path) # TextLoader 處理 md 也很 OK
    else:
        return None

    docs = loader.load()
    
    # 切分文本
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=100)
    chunks = text_splitter.split_documents(docs)
    
    texts = [c.page_content for c in chunks]
    metadatas = [
        {
            "doc_id": doc_id,
            "filename": filename,
            "page": c.metadata.get("page", 0),
            "allowed_roles": ",".join(allowed_roles)
        } for c in chunks
    ]
    ids = [f"{doc_id}_{i}" for i in range(len(chunks))]
    
    add_to_vector_db(texts, metadatas, ids)
    return doc_id

async def perform_qa(question: str, user_role: str):
    # 建立過濾器：只檢索 user_role 在 allowed_roles 裡面的文件
    # 注意：ChromaDB 的 $contains 在某些版本有限制，這裡我們用簡單邏輯或後處理
    # 為了 MVP，我們先抓出來再過濾，或者假設權限儲存為字串包含
    
    results = query_vector_db(question, n_results=5)
    
    relevant_chunks = []
    sources = []
    
    if results["documents"]:
        for i in range(len(results["documents"][0])):
            doc_text = results["documents"][0][i]
            meta = results["metadatas"][0][i]
            
            # 權限檢查
            allowed = meta.get("allowed_roles", "employee").split(",")
            if user_role in allowed or user_role == "admin":
                relevant_chunks.append(doc_text)
                sources.append(Source(
                    doc_name=meta["filename"],
                    chunk_text=doc_text[:100] + "...",
                    page_or_section=str(meta.get("page", 0))
                ))

    if not relevant_chunks:
        return "找不到依據，請確認是否已上傳相關規章文件（如請假、加班規定）。", []

    llm = get_llm()
    context = "\n\n".join(relevant_chunks)
    prompt = f"你是一位企業 AI 助理。請根據以下參考資訊回答問題：\n\n{context}\n\n問題：{question}\n\n請務必基於資訊回答，若資訊不足請直說「找不到依據」。"
    
    if llm:
        response = llm.invoke(prompt)
        answer = response.content
    else:
        # Mock Answer for Demo
        answer = f"[Demo Mode] 這是基於檢索內容的模擬回答。檢索到了 {len(relevant_chunks)} 段相關資訊。內容摘要：{relevant_chunks[0][:50]}..."

    return answer, sources

async def generate_form(template_type: str, inputs: dict, user_role: str):
    llm = get_llm()
    
    templates = {
        "請假通知": "請幫我生成一份正式的請假通知。細節如下：{inputs}",
        "加班申請說明": "請幫我生成一份加班申請說明。原因與時間：{inputs}",
        "變更申請摘要": "請幫我針對系統變更撰寫摘要。變更內容：{inputs}",
        "會議紀錄": "請根據以下重點整理成正式會議紀錄：{inputs}"
    }
    
    prompt_template = templates.get(template_type, "請幫我生成一份正式文件：{inputs}")
    prompt = prompt_template.format(inputs=str(inputs))
    
    if llm:
        response = llm.invoke(prompt)
        content = response.content
    else:
        content = f"[Demo Mode] 已為 {user_role} 生成「{template_type}」內容：\n\n親愛的團隊，\n關於{template_type}，細節如下：{inputs}。\n\n此致，\n{user_role} 助理代筆"

    return content

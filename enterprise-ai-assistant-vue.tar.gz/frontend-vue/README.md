# 企業 AI 助理 - Vue 3 + PrimeVue 前端

這是使用 **Vue 3** 和 **PrimeVue** 組件庫構建的企業 AI 助理前端。

## 🚀 快速開始

### 安裝依賴
```bash
npm install
```

### 開發模式
```bash
npm run dev
```
訪問 `http://localhost:3000`

### 構建生產版本
```bash
npm run build
```

## 📁 專案結構

```
frontend-vue/
├── src/
│   ├── App.vue          # 主應用元件
│   ├── main.js          # 應用入口
│   └── assets/          # 靜態資源
├── index.html           # HTML 模板
├── vite.config.js       # Vite 配置
└── package.json         # 依賴配置
```

## 🎨 功能特性

### 三欄布局
- **左欄**：文件管理（上傳、列表、刪除）
- **中欄**：智能問答（基於 RAG 的回答）
- **右欄**：表單生成（多種模板）

### 核心功能
- ✅ 文件上傳（PDF/TXT/MD）
- ✅ 向量檢索與問答
- ✅ 表單模板生成
- ✅ 角色權限管理
- ✅ 實時通知反饋

## 🔌 API 整合

所有 API 調用都連接到後端：`http://localhost:8000`

### 主要端點
- `POST /api/docs/upload` - 上傳文件
- `GET /api/docs` - 列出文件
- `DELETE /api/docs/{doc_id}` - 刪除文件
- `POST /api/qa` - 提交問題
- `POST /api/generate` - 生成表單內容

## 🛠️ 技術棧

- **Vue 3** - 漸進式 JavaScript 框架
- **PrimeVue** - 企業級 UI 組件庫
- **Vite** - 現代前端構建工具
- **Axios** - HTTP 客戶端

## 📝 使用說明

### 上傳文件
1. 點擊「選擇文件」
2. 選擇 PDF/TXT/MD 文件
3. 選擇允許查看的角色
4. 點擊「上傳文件」

### 提問
1. 在問答區輸入問題
2. 點擊「提交問題」
3. 查看回答和引用來源

### 生成表單
1. 選擇表單模板
2. 填寫表單欄位
3. 點擊「生成內容」
4. 複製生成的文本

## 🔐 角色管理

支援三種角色：
- **employee** - 員工
- **manager** - 主管
- **hr** - 人資

## 📚 組件使用

### PrimeVue 組件
- `Card` - 卡片容器
- `Button` - 按鈕
- `Dropdown` - 下拉選擇
- `InputText` - 文本輸入
- `Textarea` - 文本區域
- `Toast` - 通知提示

## 🐛 故障排除

### 連接後端失敗
確保後端運行在 `http://localhost:8000`

### 樣式不顯示
檢查 PrimeVue 主題 CSS 是否正確加載

### 文件上傳失敗
確保文件格式為 PDF/TXT/MD

## 📞 支援

查閱根目錄的 README.md 獲取完整文檔。

<template>
  <div class="app-container">
    <div class="header">
      <h1>企業 AI 助理</h1>
      <p>文件查詢、RAG 問答、表單生成一站式解決方案</p>
    </div>

    <div class="role-selector">
      <label>當前角色：</label>
      <Dropdown 
        v-model="userRole" 
        :options="roles" 
        option-label="label" 
        option-value="value"
        class="w-40"
      />
    </div>

    <div class="main-grid">
      <!-- 左欄：文件管理 -->
      <Card class="left-panel">
        <template #header>
          <div class="panel-header">
            <i class="pi pi-file"></i>
            <span>文件管理</span>
          </div>
        </template>
        
        <template #content>
          <div class="panel-content">
            <!-- 上傳區域 -->
            <div class="upload-area">
              <input 
                type="file" 
                ref="fileInput"
                @change="onFileSelected"
                accept=".pdf,.txt,.md"
                style="display: none"
              />
              <div class="upload-box" @click="$refs.fileInput.click()">
                <i class="pi pi-upload"></i>
                <p>選擇文件 (PDF/TXT/MD)</p>
                <p v-if="selectedFile" class="file-name">{{ selectedFile.name }}</p>
              </div>
            </div>

            <!-- 角色選擇 -->
            <div class="role-input">
              <label>允許查看角色</label>
              <Dropdown 
                v-model="uploadRoles" 
                :options="roleOptions" 
                multiple
                class="w-full"
              />
            </div>

            <Button 
              @click="uploadFile" 
              :loading="uploadLoading"
              class="w-full"
              label="上傳文件"
            />

            <!-- 文件列表 -->
            <div class="file-list">
              <h4>已上傳文件</h4>
              <div v-if="documents.length === 0" class="empty-state">
                暫無文件
              </div>
              <div v-else class="file-items">
                <div v-for="doc in documents" :key="doc.id" class="file-item">
                  <span>{{ doc.filename }}</span>
                  <Button 
                    icon="pi pi-trash" 
                    severity="danger" 
                    text
                    @click="deleteDocument(doc.id)"
                  />
                </div>
              </div>
            </div>
          </div>
        </template>
      </Card>

      <!-- 中欄：問答區 -->
      <Card class="middle-panel">
        <template #header>
          <div class="panel-header">
            <i class="pi pi-comments"></i>
            <span>智能問答</span>
          </div>
        </template>

        <template #content>
          <div class="panel-content">
            <Textarea 
              v-model="question" 
              placeholder="請輸入您的問題..."
              :auto-resize="true"
              class="w-full"
              rows="5"
            />

            <Button 
              @click="askQuestion" 
              :loading="qaLoading"
              class="w-full mt-3"
              label="提交問題"
            />

            <!-- 回答顯示 -->
            <div v-if="qaResponse" class="qa-response">
              <div class="answer-section">
                <h4>回答</h4>
                <p class="answer-text">{{ qaResponse.answer }}</p>
              </div>

              <div v-if="qaResponse.sources.length > 0" class="sources-section">
                <h4>引用來源</h4>
                <div v-for="(source, idx) in qaResponse.sources" :key="idx" class="source-card">
                  <p class="source-title">{{ source.doc_name }}</p>
                  <p class="source-text">{{ source.chunk_text }}</p>
                  <p class="source-page">頁碼: {{ source.page_or_section }}</p>
                </div>
              </div>
            </div>
          </div>
        </template>
      </Card>

      <!-- 右欄：表單生成 -->
      <Card class="right-panel">
        <template #header>
          <div class="panel-header">
            <i class="pi pi-file-edit"></i>
            <span>表單生成</span>
          </div>
        </template>

        <template #content>
          <div class="panel-content">
            <!-- 模板選擇 -->
            <div class="template-select">
              <label>選擇模板</label>
              <Dropdown 
                v-model="templateType" 
                :options="templates"
                class="w-full"
              />
            </div>

            <!-- 動態表單欄位 -->
            <div class="form-fields">
              <div v-for="field in currentTemplateFields" :key="field" class="form-field">
                <label>{{ field }}</label>
                <InputText 
                  v-model="formInputs[field]"
                  :placeholder="`輸入 ${field}`"
                  class="w-full"
                />
              </div>
            </div>

            <Button 
              @click="generateForm" 
              :loading="formLoading"
              class="w-full"
              label="生成內容"
            />

            <!-- 生成結果 -->
            <div v-if="generatedContent" class="generated-result">
              <h4>生成結果</h4>
              <Textarea 
                v-model="generatedContent" 
                :auto-resize="true"
                readonly
                class="w-full"
                rows="8"
              />
              <Button 
                @click="copyContent" 
                class="w-full mt-2"
                label="複製內容"
                icon="pi pi-copy"
              />
            </div>
          </div>
        </template>
      </Card>
    </div>

    <!-- Toast 通知 -->
    <Toast />
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import axios from 'axios'
import { useToast } from 'primevue/usetoast'
import Card from 'primevue/card'
import Button from 'primevue/button'
import Dropdown from 'primevue/dropdown'
import InputText from 'primevue/inputtext'
import Textarea from 'primevue/textarea'
import Toast from 'primevue/toast'

const toast = useToast()
const API_BASE = 'http://localhost:8000'

// 狀態
const userRole = ref('employee')
const selectedFile = ref(null)
const uploadRoles = ref(['employee'])
const uploadLoading = ref(false)
const documents = ref([])

const question = ref('')
const qaResponse = ref(null)
const qaLoading = ref(false)

const templateType = ref('請假通知')
const formInputs = ref({})
const generatedContent = ref('')
const formLoading = ref(false)

// 選項
const roles = ref([
  { label: '員工 (Employee)', value: 'employee' },
  { label: '主管 (Manager)', value: 'manager' },
  { label: '人資 (HR)', value: 'hr' }
])

const roleOptions = ref(['employee', 'manager', 'hr'])

const templates = ref([
  '請假通知',
  '加班申請說明',
  '變更申請摘要',
  '會議紀錄'
])

const templateFieldsMap = {
  '請假通知': ['請假類型', '請假日期', '請假天數', '原因'],
  '加班申請說明': ['加班日期', '加班時數', '加班原因', '預期完成時間'],
  '變更申請摘要': ['變更項目', '變更內容', '影響範圍', '實施時間'],
  '會議紀錄': ['會議名稱', '出席人員', '主要議題', '決議事項']
}

const currentTemplateFields = computed(() => {
  return templateFieldsMap[templateType.value] || []
})

const fileInput = ref(null)

// 方法
const onFileSelected = (event) => {
  selectedFile.value = event.target.files[0]
}

const uploadFile = async () => {
  if (!selectedFile.value) {
    toast.add({ severity: 'error', summary: '錯誤', detail: '請選擇文件', life: 3000 })
    return
  }

  uploadLoading.value = true
  try {
    const formData = new FormData()
    formData.append('file', selectedFile.value)
    formData.append('allowed_roles', uploadRoles.value.join(','))

    const response = await axios.post(`${API_BASE}/api/docs/upload`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })

    toast.add({ 
      severity: 'success', 
      summary: '成功', 
      detail: `文件「${response.data.filename}」上傳成功`, 
      life: 3000 
    })
    selectedFile.value = null
    loadDocuments()
  } catch (error) {
    toast.add({ severity: 'error', summary: '錯誤', detail: '文件上傳失敗', life: 3000 })
  } finally {
    uploadLoading.value = false
  }
}

const loadDocuments = async () => {
  try {
    const response = await axios.get(`${API_BASE}/api/docs`)
    documents.value = response.data
  } catch (error) {
    console.error('載入文件失敗', error)
  }
}

const deleteDocument = async (docId) => {
  try {
    await axios.delete(`${API_BASE}/api/docs/${docId}`)
    toast.add({ severity: 'success', summary: '成功', detail: '文件已刪除', life: 3000 })
    loadDocuments()
  } catch (error) {
    toast.add({ severity: 'error', summary: '錯誤', detail: '刪除失敗', life: 3000 })
  }
}

const askQuestion = async () => {
  if (!question.value.trim()) {
    toast.add({ severity: 'error', summary: '錯誤', detail: '請輸入問題', life: 3000 })
    return
  }

  qaLoading.value = true
  try {
    const response = await axios.post(`${API_BASE}/api/qa`, {
      question: question.value,
      user_role: userRole.value
    })
    qaResponse.value = response.data
  } catch (error) {
    toast.add({ severity: 'error', summary: '錯誤', detail: '問答失敗', life: 3000 })
  } finally {
    qaLoading.value = false
  }
}

const generateForm = async () => {
  if (Object.keys(formInputs.value).length === 0) {
    toast.add({ severity: 'error', summary: '錯誤', detail: '請填寫表單內容', life: 3000 })
    return
  }

  formLoading.value = true
  try {
    const response = await axios.post(`${API_BASE}/api/generate`, {
      template_type: templateType.value,
      inputs: formInputs.value,
      user_role: userRole.value
    })
    generatedContent.value = response.data.content
    toast.add({ severity: 'success', summary: '成功', detail: '內容已生成', life: 3000 })
  } catch (error) {
    toast.add({ severity: 'error', summary: '錯誤', detail: '生成失敗', life: 3000 })
  } finally {
    formLoading.value = false
  }
}

const copyContent = () => {
  navigator.clipboard.writeText(generatedContent.value)
  toast.add({ severity: 'success', summary: '成功', detail: '已複製到剪貼板', life: 3000 })
}

// 初始化
onMounted(() => {
  loadDocuments()
})
</script>

<style scoped>
.app-container {
  min-height: 100vh;
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
  padding: 2rem;
}

.header {
  text-align: center;
  margin-bottom: 2rem;
  color: #333;
}

.header h1 {
  font-size: 2.5rem;
  margin: 0;
  font-weight: 700;
}

.header p {
  font-size: 1rem;
  color: #666;
  margin: 0.5rem 0 0 0;
}

.role-selector {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 2rem;
  justify-content: center;
}

.role-selector label {
  font-weight: 600;
  color: #333;
}

.main-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 2rem;
  max-width: 1400px;
  margin: 0 auto;
}

.left-panel,
.middle-panel,
.right-panel {
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.panel-header {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 1.1rem;
  font-weight: 600;
  color: #333;
}

.panel-header i {
  font-size: 1.3rem;
}

.panel-content {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.upload-area {
  margin-bottom: 1rem;
}

.upload-box {
  border: 2px dashed #ccc;
  border-radius: 8px;
  padding: 2rem;
  text-align: center;
  cursor: pointer;
  transition: all 0.3s ease;
}

.upload-box:hover {
  border-color: #2196f3;
  background-color: #f0f7ff;
}

.upload-box i {
  font-size: 2rem;
  color: #999;
  display: block;
  margin-bottom: 0.5rem;
}

.upload-box p {
  margin: 0.5rem 0;
  color: #666;
}

.file-name {
  color: #2196f3 !important;
  font-weight: 600;
  font-size: 0.9rem;
}

.role-input {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.role-input label {
  font-weight: 600;
  color: #333;
  font-size: 0.9rem;
}

.file-list {
  margin-top: 1rem;
}

.file-list h4 {
  margin: 0 0 0.5rem 0;
  color: #333;
  font-size: 0.95rem;
}

.empty-state {
  color: #999;
  font-size: 0.9rem;
  text-align: center;
  padding: 1rem;
}

.file-items {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.file-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #f5f5f5;
  padding: 0.75rem;
  border-radius: 4px;
  font-size: 0.9rem;
}

.qa-response {
  background-color: #e3f2fd;
  padding: 1rem;
  border-radius: 8px;
  margin-top: 1rem;
}

.answer-section {
  margin-bottom: 1rem;
}

.answer-section h4 {
  margin: 0 0 0.5rem 0;
  color: #1976d2;
  font-size: 0.95rem;
}

.answer-text {
  color: #333;
  line-height: 1.6;
  white-space: pre-wrap;
  word-break: break-word;
}

.sources-section h4 {
  margin: 1rem 0 0.5rem 0;
  color: #1976d2;
  font-size: 0.95rem;
}

.source-card {
  background-color: white;
  padding: 0.75rem;
  border-left: 3px solid #2196f3;
  border-radius: 4px;
  margin-bottom: 0.5rem;
  font-size: 0.85rem;
}

.source-title {
  margin: 0 0 0.25rem 0;
  font-weight: 600;
  color: #333;
}

.source-text {
  margin: 0 0 0.25rem 0;
  color: #666;
  line-height: 1.4;
}

.source-page {
  margin: 0;
  color: #999;
  font-size: 0.8rem;
}

.template-select {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.template-select label {
  font-weight: 600;
  color: #333;
  font-size: 0.9rem;
}

.form-fields {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.form-field {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}

.form-field label {
  font-weight: 600;
  color: #333;
  font-size: 0.85rem;
}

.generated-result {
  background-color: #e8f5e9;
  padding: 1rem;
  border-radius: 8px;
  margin-top: 1rem;
}

.generated-result h4 {
  margin: 0 0 0.5rem 0;
  color: #388e3c;
  font-size: 0.95rem;
}

.mt-3 {
  margin-top: 1rem;
}

.mt-2 {
  margin-top: 0.5rem;
}

.w-full {
  width: 100%;
}

.w-40 {
  width: 10rem;
}

@media (max-width: 1024px) {
  .main-grid {
    grid-template-columns: 1fr;
  }
}
</style>
